
/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <string.h>
#include <jni.h>
#include "ontology/smartcare.h"
#include <android/log.h>
#include <stdlib.h>
#include <errno.h>

#define KP_SS_NAME "X"
//#define KP_SS_ADDRESS "194.85.173.9"  // Public PetrSU SIB
//#define KP_SS_ADDRESS "127.0.0.1"     // Local SIB
#define KP_SS_ADDRESS "78.46.130.194"
#define KP_SS_PORT 10010

#include "kp.h"

#define TAG "SS"
#define KP_NS_URI "http://oss.fruct.org/smartcare#"
#define KP_PREDICATE KP_NS_URI"sendAlarm"

char* generate_uri(char *uri);

static void print_patients(JNIEnv * env, jobject o, sslog_node_t *node, const list_t *persons);
static void update_patients(JNIEnv * env, jobject thiz, sslog_sparql_result_t *result);

/*
 *   Подключаемся к Интелектуальному пространству
 *  SmartSpace node initialization by hostname_, ip_,port
 */
JNIEXPORT jlong JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_connectSmartSpace( JNIEnv* env,
                                                  jobject thiz , jstring hostname, jstring ip, jint port) {

    const char *hostname_ = (*env) -> GetStringUTFChars(env, hostname, NULL);
    const char *ip_ = (*env) -> GetStringUTFChars(env, ip, NULL);
    sslog_node_t *node;
    sslog_init();

    __android_log_print(ANDROID_LOG_INFO, TAG, "sslog_init");

    node = sslog_new_node("KP_Patient", hostname_, ip_, (int)port);

    register_ontology(node);

    __android_log_print(ANDROID_LOG_INFO, TAG, "register_ontology");

    if (sslog_node_join(node) != SSLOG_ERROR_NO) {
        __android_log_print(ANDROID_LOG_INFO, TAG, "Can't join to SS");
        return -1;
    }
    else{
        __android_log_print(ANDROID_LOG_INFO, TAG, "KP joins to SS.");
        return (jlong) node;
    }


}
/*
 *  Отключаемся от пространства
 *
 */
JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_disconnectSmartSpace( JNIEnv* env,
                                                  jobject thiz , jlong nodeDescriptor){
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;

    sslog_sbcr_unsubscribe_all(node, true);
    sslog_node_leave(node);

    __android_log_print(ANDROID_LOG_INFO, TAG, "KP leaves SS...");

    sslog_shutdown();
}

/*
 *  Init volunteer individual + person individual
 *
 */
JNIEXPORT jstring JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_initVolunteer
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }

    char *_volunteer_uri = sslog_generate_uri(CLASS_CARING);
    char *volunteer_uri  = generate_uri(_volunteer_uri);

    __android_log_print(ANDROID_LOG_INFO, TAG, "volunteer_uri %s.", volunteer_uri);

    sslog_individual_t *volunteer = sslog_new_individual(CLASS_CARING, volunteer_uri);

    if (volunteer == NULL) {
        __android_log_print(ANDROID_LOG_INFO, TAG, "Error volunteer: %s", sslog_error_get_last_text());
        return NULL;
    }
    // insert volunteer status (ready to help)
    sslog_insert_property(volunteer, PROPERTY_HELPPROVIDINGSTATUS, "READY TO HELP");
    // insert individual with properties to SmartSpace
    sslog_node_insert_individual(node, volunteer);

    return (*env)->NewStringUTF(env, volunteer_uri);
}

/*
 * Удаляем произвольного индивида по uri
 *
*/
JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_removeIndividual
( JNIEnv* env, jobject thiz , jlong nodeDescriptor, jstring individualUri){

    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }

    const char * individual_uri= (*env)->GetStringUTFChars(env, individualUri, 0);
    sslog_individual_t *ind = sslog_node_get_individual_by_uri(node, individual_uri);

    sslog_node_remove_individual_with_local(node, ind);
}

/*
 *  Push person name to SIB
 *
 */
JNIEXPORT jint JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_insertPersonName
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jstring volunteerUri, jstring name)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return -1;
    }

    //get patient from SmartSpace
    const char * volunteer_uri= (*env)->GetStringUTFChars(env, volunteerUri, 0);
    sslog_individual_t *volunteer = sslog_node_get_individual_by_uri(node, volunteer_uri);

    // properties initialization
    const char *person_name = (*env)->GetStringUTFChars(env, name, 0);
    sslog_node_insert_property(node, volunteer, PROPERTY_NAME, person_name);

    return 0;
}

/*
 * Обновление имени при его изменении в настройках
 *
*/
JNIEXPORT jint JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_updatePersonName
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jstring volunteerUri, jstring name) {
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return -1;
    }

    //get patient from SmartSpace
    const char * volunteer_uri= (*env)->GetStringUTFChars(env, volunteerUri, 0);
    sslog_individual_t *volunteer = sslog_node_get_individual_by_uri(node, volunteer_uri);

    // properties initialization
    const char *new_name = (*env)->GetStringUTFChars(env, name, 0);
    const char *previous_name = (const char *) sslog_node_get_property(node, volunteer, PROPERTY_NAME);

    if (previous_name  == NULL) {
        __android_log_print(ANDROID_LOG_INFO, TAG,"No name");
    }

    sslog_node_update_property(node, volunteer, PROPERTY_NAME, previous_name, new_name);

    return 0;
}


/*
 * Initialize patients list when volunteer run app at first time
 *
 *
 */
 JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_initPatientList
         (JNIEnv * env, jobject thiz, jlong nodeDescriptor)
 {
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }

/******************************************************************************/
     jclass* localClass = (*env)->FindClass(env, "com/petrsu/cardiacare/smartcarevolunteer/MainActivity");

    if(localClass != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init class");

    jmethodID addPatient = (*env)->GetMethodID(env, localClass,
                                          "addPatient", "(Ljava/lang/String;)V");

    if(addPatient != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init method");

/******************************************************************************/

    list_t *patients = sslog_node_get_individuals_by_class(node, CLASS_PATIENT);

    if (list_is_null_or_empty(patients) == true) {
        list_free_with_nodes(patients, NULL);
         __android_log_print(ANDROID_LOG_INFO, TAG, "There is no such individuals");
        return;
    }

    list_head_t *list_walker = NULL;

    list_for_each(list_walker, &patients->links)
    {
        list_t *n = list_entry(list_walker, list_t, links);
        sslog_individual_t *patient = (sslog_individual_t *)n->data;
        char *uri = sslog_entity_get_uri(patient);
/******************************************************************************/
        (*env)->CallVoidMethod(env, thiz, addPatient, (*env)->NewStringUTF(env, uri));
/******************************************************************************/
    }
    //Освободить память надо
 }

/*
 * Update patients list subscription
 *
 *
 */
JNIEXPORT jlong JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_initPatientListSbscr
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return -1;
    }

    /******************************************************************************/
    jclass* localClass = (*env)->FindClass(env, "com/petrsu/cardiacare/smartcarevolunteer/MainActivity");

    if(localClass != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init class");

    jmethodID addPatient = (*env)->GetMethodID(env, localClass,
                                               "addPatient", "(Ljava/lang/String;Ljava/lang/String;)V");

    if(addPatient != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init method");
    /******************************************************************************/


    list_t *patients = sslog_node_get_individuals_by_class(node, CLASS_PATIENT);

    if (list_is_null_or_empty(patients) == true) {
        list_free_with_nodes(patients, NULL);
        __android_log_print(ANDROID_LOG_INFO, TAG, "There is no such individuals");
    } else {
        //FIXME Fatal error when no patients in the SIB
        list_head_t *list_walker = NULL;

        list_for_each(list_walker, &patients->links)
        {
            list_t *n = list_entry(list_walker, list_t, links);
            sslog_individual_t *patient = (sslog_individual_t *)n->data;
            char *uri = sslog_entity_get_uri(patient);
            char *patientName = sslog_node_get_property(node, patient, PROPERTY_NAME);
            if(patientName == NULL){
                patientName = "No Name";
            }
            /******************************************************************************/
            (*env)->CallVoidMethod(env, thiz, addPatient, (*env)->NewStringUTF(env, uri), (*env)->NewStringUTF(env, patientName));
            /******************************************************************************/
        }
        //Освободить память надо
    }


    // Create a new subscription and add class to it.
    sslog_subscription_t *subscription = sslog_new_subscription(node, false);

    sslog_sbcr_add_class(subscription, CLASS_PATIENT);

    // Try to subscribe, after this we will subscribe to class
    // and will get notifications about inserting or removing
    // individuals of the subscribed class in the smart space.
    if (sslog_sbcr_subscribe(subscription) != SSLOG_ERROR_NO) {
        __android_log_print(ANDROID_LOG_INFO, TAG, "Can't subscribe to CLASS_PATIENT");
        return -1;
    }
    __android_log_print(ANDROID_LOG_INFO, TAG,"subscribtion o CLASS_PATIENT successfull");

    return (jlong) subscription;

}
/*
 * this subsribes to patients list and transfers added or removed patients to JAVA callback-function.
 * this function should be called in another thread
 *
 */
JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_updatePatientList
        (JNIEnv * env, jobject thiz, jlong nodeDescriptor, jlong sbscrDescriptor)
{

    __android_log_print(ANDROID_LOG_INFO, TAG,"in updatePatientList");
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }
    sslog_subscription_t *subscription = (sslog_subscription_t *) sbscrDescriptor;
    if(subscription == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Subscription Error");
        return NULL;
    }
    /*
     * 1)Получаем новых пациентов
     * 2)Получаем изменения у старых пациентов
     * 3)Находим удалившихся пациентов
     *
     */

    while (sslog_sbcr_is_active(subscription) == true) {
        sslog_sbcr_wait(subscription);
        sslog_sbcr_changes_t *changes = sslog_sbcr_get_changes_last(subscription);

        const list_t *inserted_ind =
                sslog_sbcr_ch_get_individual_by_action(changes, SSLOG_ACTION_INSERT);

        print_patients(env, thiz, node, inserted_ind);

    }
}
JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_stopPatientListSbscr
(JNIEnv *env, jobject thiz, jlong nodeDescriptor, jlong sbscrDescriptor)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }
    sslog_subscription_t *subscription = (sslog_subscription_t *) sbscrDescriptor;
    if(subscription == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Subscription Error");
        return NULL;
    }
    //TODO Придумать, зачем нужна эта функция
}


static void print_patients(JNIEnv * env, jobject thiz, sslog_node_t *node, const list_t *persons){

    if (persons == NULL) {
        return;
    }

    /******************************************************************************/
    jclass* localClass = (*env)->FindClass(env, "com/petrsu/cardiacare/smartcarevolunteer/MainActivity");

    if(localClass != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init class");

    jmethodID addPatient = (*env)->GetMethodID(env, localClass,
                                               "addPatient", "(Ljava/lang/String;Ljava/lang/String;)V");

    if(addPatient != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init method");

    /******************************************************************************/


    list_head_t *list_walker = NULL;

    list_for_each(list_walker, &persons->links) {

        list_t *list_node = list_entry(list_walker, list_t, links);

        char *_uri = (char *) list_node->data;

        // After subscription new individuals will be created, and here
        // get individual from the repository.
        sslog_individual_t *patient = sslog_get_individual(_uri);

        if (patient == NULL) {
            __android_log_print(ANDROID_LOG_INFO, TAG, "No individual in the local store");
            continue;
        }

        char *uri = sslog_entity_get_uri(patient);
        char *patientName = sslog_node_get_property(node, patient, PROPERTY_NAME);
        if(patientName == NULL){
            patientName = "No Name";
        }
        __android_log_print(ANDROID_LOG_INFO, TAG, "Indiviual URI: %s\n", uri);

        /******************************************************************************/
        (*env)->CallVoidMethod(env, thiz, addPatient, (*env)->NewStringUTF(env, uri), (*env)->NewStringUTF(env, patientName));
        /******************************************************************************/
        __android_log_print(ANDROID_LOG_INFO, TAG, "After add patient");

    }
    //list_free_with_nodes(persons, NULL);
}
/*
*Initialize alarm subscription and return pointer
*/
JNIEXPORT jlong JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_initAlarmSbcr
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jstring volunteer_uri){

    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return -1;
    }

    sslog_individual_t *volunteer = sslog_node_get_individual_by_uri(node, volunteer_uri);

    // Create a new subscription and add class to it.
    sslog_subscription_t *subscription = sslog_new_subscription(node, false);
    // printf("\n  sslog_new_subscription\n");

    list_t* properties = list_new();
    list_add_data(properties, PROPERTY_HELPPROVIDINGSTATUS);

    sslog_sbcr_add_individual(subscription, volunteer, properties);

    //printf("\n sslog_sbcr_add_class\n");

    // Try to subscribe, after this we will subscribe to class
    // and will get notifications about inserting or removing
    // individuals of the subscribed class in the smart space.
    if (sslog_sbcr_subscribe(subscription) != SSLOG_ERROR_NO) {
        __android_log_print(ANDROID_LOG_INFO, TAG,"Can't subscribe.\n");
        sslog_shutdown();
        return 0;
    }
    __android_log_print(ANDROID_LOG_INFO, TAG,"subscribtion successfull\n");

    return (jlong) subscription;
}

JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_updateAlarmList
    (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jlong sbcrDescriptor, jstring volunteer_uri){

/******************************************************************************/
    jclass* localClass = (*env)->FindClass(env, "com/petrsu/cardiacare/smartcarevolunteer/MainActivity");

    if(localClass != NULL)
    __android_log_print(ANDROID_LOG_INFO, TAG, "init class");

    jmethodID alReqConfirm = (*env)->GetMethodID(env, localClass,
                                                  "alarmRequestConfirmation", "()V");
/******************************************************************************/

     //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }


    sslog_individual_t *volunteer = sslog_node_get_individual_by_uri(node, volunteer_uri);



    sslog_subscription_t *subscription = (sslog_subscription_t *) sbcrDescriptor;
    if(subscription == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Alarm Subscription Error");
        return NULL;
    }

    while (sslog_sbcr_is_active(subscription) == true){

        sslog_sbcr_wait(subscription);

        sslog_sbcr_changes_t *changes =
                sslog_sbcr_get_changes_last(subscription);

        sslog_sbcr_ch_print(changes);
        const list_t *status_list =
            sslog_sbcr_ch_get_triples(changes, SSLOG_ACTION_INSERT);
        if (status_list == NULL) {
            continue;
        }
        list_head_t *iterator = NULL;
        list_for_each(iterator, &status_list->links) {
            list_t *list_node = list_entry(iterator, list_t, links);
            sslog_triple_t *status = (sslog_triple_t *) list_node->data;
            if (strcmp(status->object, "HELP REQUEST") == 0) {

/******************************************************************************/
                (*env)->CallVoidMethod(env, thiz, alReqConfirm);
/******************************************************************************/


                sslog_sbcr_unsubscribe(subscription);
                sslog_node_update_property(node, volunteer, PROPERTY_HELPPROVIDINGSTATUS, "HELP REQUEST", "REJECTED");
                return;
            }
        }
    }
}
/**
 * @brief Prints SPARQL SELECT result.
 * @param result Result to print.
 */
static void update_patients(JNIEnv * env, jobject thiz, sslog_sparql_result_t *result)
{
    /******************************************************************************/
    jclass* localClass = (*env)->FindClass(env, "com/petrsu/cardiacare/smartcarevolunteer/MainActivity");

    if(localClass != NULL)
        __android_log_print(ANDROID_LOG_INFO, TAG, "init class");

    jmethodID updatePatient = (*env)->GetMethodID(env, localClass,
                                               "updatePatient", "(Ljava/lang/String;)V");
    /******************************************************************************/

    if (result == NULL || result->rows_count == 0) {
        __android_log_print(ANDROID_LOG_INFO, TAG,"No result to print.");
        return NULL;
    }
    for (int i = 0; i < result->rows_count; ++i) {
        __android_log_print(ANDROID_LOG_INFO, TAG,"Call Update Patient N %i", i + 1);
        /******************************************************************************/
        (*env)->CallVoidMethod(env, thiz, updatePatient, (*env)->NewStringUTF(env, result->rows[i]->values[1]));
        /******************************************************************************/
    }
}


JNIEXPORT void JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_stopAlarmListSbcr
(JNIEnv *env, jobject thiz, jlong nodeDescriptor, jlong sbscrDescriptor){
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }
    sslog_subscription_t *subscription = (sslog_subscription_t *) sbscrDescriptor;
    if(subscription == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Subscription Error");
        return NULL;
    }
    //TODO Придумать, зачем нужна эта функция
}

/*
 * Инициализируем индивид локации (возвращает сгенерированный ЮРИ локации)
 *
 */
JNIEXPORT jstring JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_initLocation
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jstring individualUri)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return NULL;
    }

    //get individual from SmartSpace
    const char * individual_uri= (*env)->GetStringUTFChars(env, individualUri, 0);
    sslog_individual_t *ind = sslog_node_get_individual_by_uri(node, individual_uri);


    //Create Location individual with latitude and longitude properties
    char * _location_uri = sslog_generate_uri(CLASS_LOCATION);
    char *location_uri = generate_uri(_location_uri);

    __android_log_print(ANDROID_LOG_INFO, TAG, "location_uri %s.", location_uri);

    sslog_individual_t *location = sslog_new_individual(CLASS_LOCATION, location_uri);

    if (location == NULL) {
        __android_log_print(ANDROID_LOG_INFO, TAG, "Error location: %s", sslog_error_get_last_text());
        return NULL;
    }

    // Location properties initialization
    sslog_insert_property(location, PROPERTY_LAT, "0.0");
    sslog_insert_property(location, PROPERTY_LONG, "0.0");

    // insert individual with properties to SmartSpace
    sslog_node_insert_individual(node, location);
    // insert location property to specific individual
    sslog_node_insert_property(node, ind, PROPERTY_HASPERSLOCATION, location);

    return (*env)->NewStringUTF(env, location_uri);
}
/*
 *
 * Отпралвяем локацию. В разработке
 */
JNIEXPORT jint JNICALL Java_com_petrsu_cardiacare_smartcarevolunteer_MainActivity_sendLocation
        (JNIEnv *env, jobject thiz, jlong nodeDescriptor, jstring patientUri, jstring locationUri, jstring latitudeJ, jstring longitudeJ)
{
    //get node from SmartSpace
    sslog_node_t *node = (sslog_node_t *) nodeDescriptor;
    if (node == NULL){
        __android_log_print(ANDROID_LOG_INFO, TAG, "Node Error");
        return -1;
    }
    //get location from SmartSpace
    const char * location_uri= (*env)->GetStringUTFChars(env, locationUri, 0);
    sslog_individual_t *location = sslog_node_get_individual_by_uri(node, location_uri);

    //update in SmartSpace Location's property: latitude
    const char *latitude = (*env)->GetStringUTFChars(env, latitudeJ, 0);
    char *latitude_from_ss = sslog_node_get_property(node, location,  PROPERTY_LAT);
    __android_log_print(ANDROID_LOG_INFO, TAG, "latitude_from_ss %s",latitude_from_ss);
    __android_log_print(ANDROID_LOG_INFO, TAG, "latitude %s",latitude);
    sslog_node_update_property(node, location,  PROPERTY_LAT, latitude_from_ss,latitude);

    //update in SmartSpace Location's property: longitude
    const char *longitude = (*env)->GetStringUTFChars(env, longitudeJ, 0);
    char *longitude_from_ss = sslog_node_get_property(node, location,  PROPERTY_LONG);
    __android_log_print(ANDROID_LOG_INFO, TAG, "longitudee_from_ss %s",longitude_from_ss);
    __android_log_print(ANDROID_LOG_INFO, TAG, "longitude %s",longitude);
    sslog_node_update_property(node, location,  PROPERTY_LONG, longitude_from_ss,longitude);

    return 0;
}

/*
 * Генерация добавки для URI
 */
char* generate_uri(char *uri){
    static int i = 0;

    int rnd_num = rand() % 100000 + i;
    i++;

    char *hash = (char *) malloc(sizeof(rnd_num));

    if (hash == NULL) return NULL;

    sprintf(hash, "%i", rnd_num);

    strncat(uri, hash, strlen(hash));

    return uri;
}


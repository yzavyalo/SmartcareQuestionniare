#ifndef SSAP_MSG_COMMON_H
#define SSAP_MSG_COMMON_H

#define URI_STRING  "uri"
#define LITERAL_STRING "literal"
#define BNODE_STRING "bnode"

#endif

//
// Created by nikolay on 19.01.16.
//
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "handlers.h"
#include <stdbool.h>
#include <android/log.h>
#include <jni.h>
#include "globals.h"

#define TAG "SS"


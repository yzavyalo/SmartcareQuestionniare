//
// Created by nikolay on 19.01.16.
//
#ifdef	__cplusplus
extern "C" {
#endif
#ifndef SMARTCARE_QUESTIONNAIRE_HANDLERS_H
#define SMARTCARE_QUESTIONNAIRE_HANDLERS_H

#endif //SMARTCARE_QUESTIONNAIRE_HANDLERS_H

#include "ontology/smartcare.h"

#ifdef	__cplusplus
}
#endif
//
// Created by nikolay on 20.01.16.
//

#ifndef SMARTCARE_QUESTIONNAIRE_JNI_UTILS_H
#define SMARTCARE_QUESTIONNAIRE_JNI_UTILS_H

#endif //SMARTCARE_QUESTIONNAIRE_JNI_UTILS_H

int init_global_instances(JNIEnv*,jobject);

int init_JVM_instance(JNIEnv*);